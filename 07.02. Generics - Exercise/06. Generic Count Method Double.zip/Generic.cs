﻿using System.Collections.Generic;
using System.ComponentModel;

namespace Generic
{
    public class Generic
    {
        public List<double> list = new List<double>();
        public void Add(double word)
        {
            list.Add(word);
        }
        public int CountOfElements(double input)
        {
            int counter = 0;
            foreach (var item in list)
            {
                if (item > input)
                {
                    counter++;
                }
            }
            return counter;
        }
    }
}
