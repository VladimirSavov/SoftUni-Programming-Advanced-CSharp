﻿namespace SoftUniKindergarten
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Kindergarten kindergarten = new Kindergarten("Space S", 8);

            Child childOne = new Child("B","D", 5, "Parent Name", "0877 877 015");
            Child childTwo= new Child("B","B", 5, "Parent Name", "0877 877 016");

            System.Console.WriteLine(kindergarten.AddChild(childOne));
            System.Console.WriteLine(kindergarten.AddChild(childTwo));

            System.Console.WriteLine(kindergarten.RemoveChild("Ruzha Ignatova"));
            System.Console.WriteLine(kindergarten.RemoveChild("George Bush"));
            System.Console.WriteLine(kindergarten.RemoveChild("Elona Muskova"));
            System.Console.WriteLine(kindergarten.RemoveChild("Ruzha Ignatova"));
            System.Console.WriteLine(kindergarten.RemoveChild("Tim Duncan"));

            System.Console.WriteLine(kindergarten.ChildrenCount());

            System.Console.WriteLine(kindergarten.GetChild("S Rex"));

            System.Console.WriteLine(kindergarten.RegistryReport());

        }
    }
}
