﻿using System.Collections.Generic;
using System.ComponentModel;

namespace Generic
{
    public class Generic
    {
        public List<string> list = new List<string>();
        public void Add(string word)
        {
            list.Add(word);
        }
        public int CountOfElements(string[] input)
        {
            int countOfInput = 0;
            int countOfList = 0;
            int counter = 0;
            foreach (var item in input)
            {
                foreach (char c in item)
                {
                    countOfInput += c;
                }
            }
            foreach (var item in list)
            {
                foreach (char c in item)
                {
                    countOfList += c;
                }
                if(countOfInput < countOfList)
                {
                    counter++;
                }
                countOfList = 0;
            }
            return counter;
        }
    }
}
