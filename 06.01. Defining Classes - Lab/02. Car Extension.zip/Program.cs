﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Tracing;
using System.Linq;

namespace CarManufacturer
{
    public class Car 
    {
        private string make;
        private string model;
        private int year;
        private double fuelQuantity;
        private double fuelConsumption;

        public string Make { get { return make; } set { make = value; } }
        public string Model { get { return model; } set { model = value; } }
        public int Year { get { return year; } set { year = value; } }
        public double FuelQuantity { get { return fuelQuantity; } set { fuelQuantity = value; } }
        public double FuelConsumption { get { return fuelConsumption; } set { fuelConsumption = value; } }

        public string WhoIAm()
        {
            return $"{Make} {Model} ({Year})";
        }
        public void Drive(double distance)
        {
            var consumption = distance * (FuelConsumption / 100.0);
            if(consumption <= FuelQuantity)
            {
                FuelQuantity -= consumption;
            }
            else
            {
                Console.WriteLine($"Cannot drive {distance:F2} km.");
            }
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.Make = "VW";
            car.Model = "MK3";
            car.Year = 1992;
            car.FuelQuantity = 80;
            car.FuelConsumption = 15;
            car.Drive(200);
            car.Drive(200);
            car.Drive(100);
            car.Drive(34);
            Console.WriteLine(car.WhoIAm());
        }
    }
}