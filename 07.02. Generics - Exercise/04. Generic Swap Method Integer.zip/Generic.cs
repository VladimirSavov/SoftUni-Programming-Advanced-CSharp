﻿using System.Collections.Generic;
using System.ComponentModel;

namespace Generic
{
    public class Generic<T>
    {
        public List<T> list = new List<T>();
        public void Add(T word)
        {
            list.Add(word);
        }
        public List<T> SwapElements(int[] arr)
        {
            T swapElement = list[arr[0]];
            list[arr[0]] = list[arr[1]];
            list[arr[1]] = swapElement;
            return list;
        }
    }
}
