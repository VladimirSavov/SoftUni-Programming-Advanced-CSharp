﻿namespace GenericBox
{
    public class GenericBox
    {
        public void ClassBox<T>(T word)
        {
            System.Console.WriteLine($"{typeof(T)}: {word}");
        }
    }
}
