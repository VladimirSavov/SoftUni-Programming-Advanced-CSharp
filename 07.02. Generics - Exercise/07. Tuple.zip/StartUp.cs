﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tuple
{
    class StartUp
    {
        public static void Main(string[] args)
        {
            string[] NameAndCountry = Console.ReadLine().Split().ToArray();
            MyTuple<string, string> first = new MyTuple<string, string>($"{NameAndCountry[0]} {NameAndCountry[1]}", NameAndCountry[2]);

            string[] NameAndLiters = Console.ReadLine().Split().ToArray();
            MyTuple<string, int> second = new MyTuple<string, int>(NameAndLiters[0], int.Parse(NameAndLiters[1]));

            string[] IntAndDouble = Console.ReadLine().Split().ToArray();
            MyTuple<int, double> third = new MyTuple<int, double>(int.Parse(IntAndDouble[0]), double.Parse(IntAndDouble[1]));

            Console.WriteLine(first.GetItems());
            Console.WriteLine(second.GetItems());
            Console.WriteLine(third.GetItems());
        }
    }
}
