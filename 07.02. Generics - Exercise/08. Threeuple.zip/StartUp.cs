﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Threeuple
{
    class StartUp
    {
        public static void Main(string[] args)
        {
            string isTrue = "";
            string[] NameAndTown = Console.ReadLine().Split().ToArray();
            Threeuple<string, string, string> first = new Threeuple<string, string, string>($"{NameAndTown[0]} {NameAndTown[1]}", NameAndTown[2], NameAndTown[3]);

            string[] NameAndLiters = Console.ReadLine().Split().ToArray();
            if (NameAndLiters[2] == "drunk")
            {
                isTrue = "True";
            }
            else
            {
                isTrue= "False";
            }
            Threeuple<string, int, string> second = new Threeuple<string, int, string>(NameAndLiters[0], int.Parse(NameAndLiters[1]), isTrue);

            string[] NameAndBalance = Console.ReadLine().Split().ToArray();
            Threeuple<string, double, string> third = new Threeuple<string, double, string>(NameAndBalance[0], double.Parse(NameAndBalance[1]), NameAndBalance[2]);

            Console.WriteLine(first.GetItems());
            Console.WriteLine(second.GetItems());
            Console.WriteLine(third.GetItems());
        }
    }
}
