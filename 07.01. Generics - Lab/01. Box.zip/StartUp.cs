﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoxOfT
{
    public class Box<T>
    {
        private List<T> List = new List<T>();
        public int Count
        {
            get
            {
                return List.Count;
            }
        }

        public void Add(T element)
        {
            List.Add(element);
        }
        public T ElementRemove()
        {
            T element = List[List.Count - 1];
            List.RemoveAt(List.Count - 1);
            return element;
        }
    }

    public class StartUp
    {
        static void Main(string[] args)
        {
            Box<int> box = new Box<int>();
            box.Add(1);
            box.Add(2);
            box.Add(3);
            Console.WriteLine(box.ElementRemove());
            box.Add(4);
            box.Add(5);
            Console.WriteLine(box.ElementRemove());
        }
    }
}
