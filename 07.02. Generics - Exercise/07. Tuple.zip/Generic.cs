﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Tuple
{
    public class MyTuple<Item1, Item2>
    {
        public Item1 LeftItem { get; set; }
        public Item2 RightItem { get; set; }

        public MyTuple(Item1 leftItem, Item2 rightItem)
        {
            LeftItem = leftItem;
            RightItem = rightItem;
        }

        public string GetItems()
        {
            return $"{LeftItem} -> {RightItem}";
        }
    }
}
