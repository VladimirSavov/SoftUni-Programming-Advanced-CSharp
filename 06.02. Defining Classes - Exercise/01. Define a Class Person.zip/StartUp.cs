﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Tracing;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp 
    {
        public static void Main(string[] Args)
        {
            Person person = new Person();
            person.Name = "Kiro";
            person.Age = 24;

            Console.WriteLine(person.Name);
            Console.WriteLine(person.Age);
        }

    }

}