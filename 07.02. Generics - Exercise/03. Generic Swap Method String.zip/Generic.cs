﻿using System.Collections.Generic;
using System.ComponentModel;

namespace Generic
{
    public class Generic
    {
        public List<string> list = new List<string>();
        public void Add(string word)
        {
            list.Add(word);
        }
        public List<string> SwapElements(int[] arr)
        {
            string swapElement = list[arr[0]];
            list[arr[0]] = list[arr[1]];
            list[arr[1]] = swapElement;
            return list;
        }
    }
}
