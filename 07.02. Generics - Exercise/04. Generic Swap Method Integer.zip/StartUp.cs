﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic
{
    class StartUp
    {
        public static void Main(string[] args)
        {
            Generic<int> genericBox = new Generic<int>();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                genericBox.Add(int.Parse(Console.ReadLine()));
            }
            int[] ints = Console.ReadLine().Split().Select(int.Parse).ToArray();
            Console.Write("System.Int32: ");
            Console.WriteLine(string.Join("\nSystem.Int32: ", genericBox.SwapElements(ints)));
        }
    }
}
