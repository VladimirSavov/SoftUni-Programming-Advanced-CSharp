﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorsAndComparators
{
    class StartUp
    {
        static void Main()
        {
            int[] coins = Console.ReadLine().Split(", ").Select(int.Parse).ToArray();
            int targetSum = int.Parse(Console.ReadLine());
            Dictionary<int, int> result = ChooseCoins(coins, targetSum);

            Console.WriteLine($"");

            foreach (var item in result)
            {
                Console.WriteLine($"{item.Value} coin(s) with value {item.Key}");
            }

        }
        static Dictionary<int, int> ChooseCoins(IList<int> coins, int targetSum)
        {
            int index = coins.Count - 1;
            Dictionary<int, int> coinsCount = new Dictionary<int, int>();
            while (true)
            {
                int currentCoin = coins[index];

                int result = targetSum / currentCoin;

                if(result < 1)
                {
                    index--;
                    continue;
                }

                coinsCount.Add(currentCoin, result);


                targetSum -= currentCoin * result;  

                if(targetSum == 0)
                {
                    break;
                }
            }
            return coinsCount;
            if(targetSum > 0)
            {
                throw new InvalidCastException();
            }
        }
    }
}
