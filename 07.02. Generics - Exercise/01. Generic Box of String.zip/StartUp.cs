﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericBox
{
    class StartUp
    {
        public static void Main(string[] args)
        {
            GenericBox genericBox = new GenericBox();
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                genericBox.ClassBox(Console.ReadLine());
            }
        }
    }
}
