﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace SoftUniKindergarten
{
    public class Kindergarten
    {
        public string Name { get; set; }
        public int Capacity { get; set; }
        public List<Child> Registry { get; set; }

        int currCap = 1;
        public Kindergarten(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            Registry = new List<Child>();
        }

        public bool AddChild(Child child)
        {
            if(currCap <= Capacity)
            {
                Registry.Add(child);
                currCap++;
                return true;
            }
            return false;
        }
        public bool RemoveChild(string childFullName)
        {
            string[] firstAndSecondName = childFullName.Split();
            var name = Registry.FirstOrDefault(x => x.FirstName == firstAndSecondName[0]);
            if(name == null)
            {
                return false;
            }
            else
            {
                Registry.Remove(name);
                return true;
            }
            
        }
        public int ChildrenCount()
        {
            return Registry.Count;
        }
        public string GetChild(string childFullName)
        {
            string[] firstAndSecondName = childFullName.Split().ToArray();
            var name = Registry.FirstOrDefault(x => x.FirstName == firstAndSecondName[0]);
            if(name != null)
            {
                return $"Child: {name.FirstName} {name.LastName}, Age: {name.Age}, Contact Info: {name.ParentName} - {name.ContactNumber}";
            }
            else
            {
                return null;
            }
        }
        public string RegistryReport()
        {
            Registry = Registry.OrderByDescending(x => x.Age).ThenBy(x => x.LastName).ThenBy(x => x.FirstName).ToList();
            var sb = new StringBuilder();
            sb.AppendLine($"Registered children in {Name}:");
            foreach (var reportInfo in Registry)
            {
                sb.AppendLine(reportInfo.ToString());
            }
            return sb.ToString().TrimEnd();
        }
    }
}
